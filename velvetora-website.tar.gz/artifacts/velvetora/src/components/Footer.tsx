import { Instagram, Facebook, Twitter, Mail, MapPin, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer id="footer" className="bg-[#1A1A1A] text-white pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="lg:col-span-1">
            <a href="#" className="block mb-6">
              <img src="/images/velvetora-logo.png" alt="Velvetora.v" className="h-14 w-auto object-contain brightness-0 invert" />
            </a>
            <p className="text-white/60 text-sm leading-relaxed mb-6 pr-4">
              Luxury gifting redefined. Curated hampers, premium jewellery, and artisanal stationery for life's most precious moments.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-accent hover:text-black transition-all duration-300">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-accent hover:text-black transition-all duration-300">
                <Facebook className="w-4 h-4" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-accent hover:text-black transition-all duration-300">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-display text-lg font-semibold mb-6 text-white/90">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Shop All</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Our Story</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Corporate Gifting</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Track Order</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-display text-lg font-semibold mb-6 text-white/90">Support</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">FAQ</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Returns & Exchanges</a></li>
              <li><a href="#" className="text-sm text-white/60 hover:text-accent transition-colors">Privacy Policy</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-display text-lg font-semibold mb-6 text-white/90">Contact Us</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-sm text-white/60">
                <MapPin className="w-5 h-5 text-accent shrink-0" />
                <span>123 Luxury Avenue, Fashion District, Mumbai 400001</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-white/60">
                <Phone className="w-5 h-5 text-accent shrink-0" />
                <span>+91 98765 43210</span>
              </li>
              <li className="flex items-center gap-3 text-sm text-white/60">
                <Mail className="w-5 h-5 text-accent shrink-0" />
                <span>concierge@velvetora.v</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-white/40">
            &copy; {new Date().getFullYear()} Velvetora.v. All rights reserved.
          </p>
          <div className="flex gap-4 text-xs text-white/40">
            <span>Designed with elegance.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
